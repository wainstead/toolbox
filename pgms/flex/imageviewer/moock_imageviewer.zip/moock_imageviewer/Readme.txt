This archive contains files that belong to the article at: 
http://www.adobe.com/devnet/actionscript/articles/image_viewer.html

